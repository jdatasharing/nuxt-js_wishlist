import axios from "axios";

export const state = () => ({
    items: [],
    total: null,
    loading: false
});

export const mutations = {
    initWishlist(state, payload) {
        console.log('test');
        state.items = payload.items;
        state.total = payload.total;
    },
    setItems(state, payload) {
        // console.log("set items work kre che");
        if (state.total !== null) {
            const existItem = state.items.find(item => item.id === payload.id);
            if (!existItem) {
                state.items.push({
                    id: payload.id
                });
                state.total = state.total + 1;
                let pitem =
                {
                     id: payload.id
                }
                let x = localStorage.getItem('x-token-site');
                axios.post('http://127.0.0.1:8000/api/v1/addProductWishlist',pitem,
            {headers: {
                    'Authorization': 'Bearer ' + x,
                   
                    'Content-Type':'application/json'
                  }
                  }).then(r => console.log('r: ', r));
               
               
            //     ;
            //     let x = localStorage.getItem('x-token-site');
            //     console.log("WishList Js Call");
               
            // axios.post('http://127.0.0.1:8000/api/v1/addProductWishlist',pitem,
            // {headers: {
            //         'Authorization': 'Bearer ' + x,
                   
            //         'Content-Type':'application/json'
            //       }
            //       }).then(r => console.log('r: ', r));
             
                
        }
        } else {
            state.items.push({
                id: payload.id
            });
            // console.log("the is is"+ payload.id+"try only ihghn ")
            state.total = state.total + 1;
        }
    },

    removeItem(state, payload) {
        const index = state.items.findIndex(item => item.id === payload.id);
        state.total = state.total - 1;
        state.items.splice(index, 1);
    }
};
export const actions = {
    addItemToWishlist({ commit, state }, payload) {
        console.warn("The Value Of Payload in Wishlist"+payload);
        commit('setItems', payload);
        const params = {
            items: state.items,
            total: state.total
        };

        

        this.$cookies.set('wishlist', params, {
            path: '/',
            maxAge: 60 * 60 * 24 * 7
        });


    },

    removeItemFromWishlist({ commit, state }, payload) {
        commit('removeItem', payload);
        const params = {
            items: state.items,
            total: state.total
        };

        this.$cookies.set('wishlist', params, {
            path: '/',
            maxAge: 60 * 60 * 24 * 7
        });
    }
};
