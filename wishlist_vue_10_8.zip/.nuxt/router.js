import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6ae4d4f5 = () => interopDefault(import('..\\pages\\blog\\index.vue' /* webpackChunkName: "pages/blog/index" */))
const _01dc61d2 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _2d12b7ef = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _203e8d21 = () => interopDefault(import('..\\pages\\shop\\index.vue' /* webpackChunkName: "pages/shop/index" */))
const _1c9a7c60 = () => interopDefault(import('..\\pages\\account\\addresses.vue' /* webpackChunkName: "pages/account/addresses" */))
const _798280f8 = () => interopDefault(import('..\\pages\\account\\checkout.vue' /* webpackChunkName: "pages/account/checkout" */))
const _b33314ba = () => interopDefault(import('..\\pages\\account\\compare.vue' /* webpackChunkName: "pages/account/compare" */))
const _4f12ec63 = () => interopDefault(import('..\\pages\\account\\edit-address.vue' /* webpackChunkName: "pages/account/edit-address" */))
const _51512da3 = () => interopDefault(import('..\\pages\\account\\invoice-detail.vue' /* webpackChunkName: "pages/account/invoice-detail" */))
const _2994f2d0 = () => interopDefault(import('..\\pages\\account\\invoices.vue' /* webpackChunkName: "pages/account/invoices" */))
const _229437a7 = () => interopDefault(import('..\\pages\\account\\login.vue' /* webpackChunkName: "pages/account/login" */))
const _18fe7fa6 = () => interopDefault(import('..\\pages\\account\\notifications.vue' /* webpackChunkName: "pages/account/notifications" */))
const _09e9a288 = () => interopDefault(import('..\\pages\\account\\order-tracking.vue' /* webpackChunkName: "pages/account/order-tracking" */))
const _6329f244 = () => interopDefault(import('..\\pages\\account\\payment.vue' /* webpackChunkName: "pages/account/payment" */))
const _5aa99096 = () => interopDefault(import('..\\pages\\account\\recent-viewed-product.vue' /* webpackChunkName: "pages/account/recent-viewed-product" */))
const _86ed2856 = () => interopDefault(import('..\\pages\\account\\register.vue' /* webpackChunkName: "pages/account/register" */))
const _0a939d60 = () => interopDefault(import('..\\pages\\account\\shipping.vue' /* webpackChunkName: "pages/account/shipping" */))
const _1c659eba = () => interopDefault(import('..\\pages\\account\\shopping-cart.vue' /* webpackChunkName: "pages/account/shopping-cart" */))
const _691afc48 = () => interopDefault(import('..\\pages\\account\\user-information.vue' /* webpackChunkName: "pages/account/user-information" */))
const _10b491f7 = () => interopDefault(import('..\\pages\\account\\wishlist.vue' /* webpackChunkName: "pages/account/wishlist" */))
const _39099804 = () => interopDefault(import('..\\pages\\blog\\blog-left-sidebar.vue' /* webpackChunkName: "pages/blog/blog-left-sidebar" */))
const _5cddb9e8 = () => interopDefault(import('..\\pages\\blog\\blog-list.vue' /* webpackChunkName: "pages/blog/blog-list" */))
const _76e44bad = () => interopDefault(import('..\\pages\\blog\\blog-right-sidebar.vue' /* webpackChunkName: "pages/blog/blog-right-sidebar" */))
const _d453cab0 = () => interopDefault(import('..\\pages\\blog\\blog-small-thumbnail.vue' /* webpackChunkName: "pages/blog/blog-small-thumbnail" */))
const _64ea6d97 = () => interopDefault(import('..\\pages\\home\\auto-part.vue' /* webpackChunkName: "pages/home/auto-part" */))
const _ba7c82b4 = () => interopDefault(import('..\\pages\\home\\electronic.vue' /* webpackChunkName: "pages/home/electronic" */))
const _701eafb8 = () => interopDefault(import('..\\pages\\home\\furniture.vue' /* webpackChunkName: "pages/home/furniture" */))
const _20fc46e0 = () => interopDefault(import('..\\pages\\home\\market-place.vue' /* webpackChunkName: "pages/home/market-place" */))
const _6519fff6 = () => interopDefault(import('..\\pages\\home\\market-place-2.vue' /* webpackChunkName: "pages/home/market-place-2" */))
const _64fdd0f4 = () => interopDefault(import('..\\pages\\home\\market-place-3.vue' /* webpackChunkName: "pages/home/market-place-3" */))
const _64e1a1f2 = () => interopDefault(import('..\\pages\\home\\market-place-4.vue' /* webpackChunkName: "pages/home/market-place-4" */))
const _149045b1 = () => interopDefault(import('..\\pages\\home\\organic.vue' /* webpackChunkName: "pages/home/organic" */))
const _926ead94 = () => interopDefault(import('..\\pages\\home\\technology.vue' /* webpackChunkName: "pages/home/technology" */))
const _ceafa390 = () => interopDefault(import('..\\pages\\page\\about-us.vue' /* webpackChunkName: "pages/page/about-us" */))
const _a19c592c = () => interopDefault(import('..\\pages\\page\\blank.vue' /* webpackChunkName: "pages/page/blank" */))
const _122689c5 = () => interopDefault(import('..\\pages\\page\\contact-us.vue' /* webpackChunkName: "pages/page/contact-us" */))
const _96e29a12 = () => interopDefault(import('..\\pages\\page\\faqs.vue' /* webpackChunkName: "pages/page/faqs" */))
const _8b889758 = () => interopDefault(import('..\\pages\\page\\page-404.vue' /* webpackChunkName: "pages/page/page-404" */))
const _07895fe6 = () => interopDefault(import('..\\pages\\post\\default.vue' /* webpackChunkName: "pages/post/default" */))
const _23ef713e = () => interopDefault(import('..\\pages\\post\\detail-2.vue' /* webpackChunkName: "pages/post/detail-2" */))
const _23d3423c = () => interopDefault(import('..\\pages\\post\\detail-3.vue' /* webpackChunkName: "pages/post/detail-3" */))
const _23b7133a = () => interopDefault(import('..\\pages\\post\\detail-4.vue' /* webpackChunkName: "pages/post/detail-4" */))
const _4bac5989 = () => interopDefault(import('..\\pages\\product\\affiliate.vue' /* webpackChunkName: "pages/product/affiliate" */))
const _edcd5934 = () => interopDefault(import('..\\pages\\product\\boxed.vue' /* webpackChunkName: "pages/product/boxed" */))
const _71b9186d = () => interopDefault(import('..\\pages\\product\\countdown.vue' /* webpackChunkName: "pages/product/countdown" */))
const _150692a6 = () => interopDefault(import('..\\pages\\product\\extended.vue' /* webpackChunkName: "pages/product/extended" */))
const _53acb4a2 = () => interopDefault(import('..\\pages\\product\\full-content.vue' /* webpackChunkName: "pages/product/full-content" */))
const _50e8ac24 = () => interopDefault(import('..\\pages\\product\\groupped.vue' /* webpackChunkName: "pages/product/groupped" */))
const _4bb3e0b1 = () => interopDefault(import('..\\pages\\product\\on-sale.vue' /* webpackChunkName: "pages/product/on-sale" */))
const _78d3e09a = () => interopDefault(import('..\\pages\\product\\out-of-stock.vue' /* webpackChunkName: "pages/product/out-of-stock" */))
const _2912f918 = () => interopDefault(import('..\\pages\\product\\sidebar.vue' /* webpackChunkName: "pages/product/sidebar" */))
const _c6eb1db4 = () => interopDefault(import('..\\pages\\shop\\shop-carousel.vue' /* webpackChunkName: "pages/shop/shop-carousel" */))
const _3a5e0462 = () => interopDefault(import('..\\pages\\shop\\shop-categories.vue' /* webpackChunkName: "pages/shop/shop-categories" */))
const _14f9177e = () => interopDefault(import('..\\pages\\shop\\shop-fullwidth.vue' /* webpackChunkName: "pages/shop/shop-fullwidth" */))
const _5ccf4506 = () => interopDefault(import('..\\pages\\shop\\shop-sidebar.vue' /* webpackChunkName: "pages/shop/shop-sidebar" */))
const _69590ca8 = () => interopDefault(import('..\\pages\\shop\\shop-sidebar-without-banner.vue' /* webpackChunkName: "pages/shop/shop-sidebar-without-banner" */))
const _2781c292 = () => interopDefault(import('..\\pages\\vendor\\become-a-vendor.vue' /* webpackChunkName: "pages/vendor/become-a-vendor" */))
const _a24e1e46 = () => interopDefault(import('..\\pages\\vendor\\store-list.vue' /* webpackChunkName: "pages/vendor/store-list" */))
const _56cd1ec2 = () => interopDefault(import('..\\pages\\vendor\\store-list-2.vue' /* webpackChunkName: "pages/vendor/store-list-2" */))
const _8486d9a2 = () => interopDefault(import('..\\pages\\vendor\\vendor-store.vue' /* webpackChunkName: "pages/vendor/vendor-store" */))
const _acab3542 = () => interopDefault(import('..\\pages\\post\\_id.vue' /* webpackChunkName: "pages/post/_id" */))
const _2de39b14 = () => interopDefault(import('..\\pages\\product\\_id.vue' /* webpackChunkName: "pages/product/_id" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: '',
  linkExactActiveClass: 'active',
  scrollBehavior,

  routes: [{
    path: "/blog",
    component: _6ae4d4f5,
    name: "blog___en"
  }, {
    path: "/fr",
    component: _01dc61d2,
    name: "index___fr"
  }, {
    path: "/search",
    component: _2d12b7ef,
    name: "search___en"
  }, {
    path: "/shop",
    component: _203e8d21,
    name: "shop___en"
  }, {
    path: "/account/addresses",
    component: _1c9a7c60,
    name: "account-addresses___en"
  }, {
    path: "/account/checkout",
    component: _798280f8,
    name: "account-checkout___en"
  }, {
    path: "/account/compare",
    component: _b33314ba,
    name: "account-compare___en"
  }, {
    path: "/account/edit-address",
    component: _4f12ec63,
    name: "account-edit-address___en"
  }, {
    path: "/account/invoice-detail",
    component: _51512da3,
    name: "account-invoice-detail___en"
  }, {
    path: "/account/invoices",
    component: _2994f2d0,
    name: "account-invoices___en"
  }, {
    path: "/account/login",
    component: _229437a7,
    name: "account-login___en"
  }, {
    path: "/account/notifications",
    component: _18fe7fa6,
    name: "account-notifications___en"
  }, {
    path: "/account/order-tracking",
    component: _09e9a288,
    name: "account-order-tracking___en"
  }, {
    path: "/account/payment",
    component: _6329f244,
    name: "account-payment___en"
  }, {
    path: "/account/recent-viewed-product",
    component: _5aa99096,
    name: "account-recent-viewed-product___en"
  }, {
    path: "/account/register",
    component: _86ed2856,
    name: "account-register___en"
  }, {
    path: "/account/shipping",
    component: _0a939d60,
    name: "account-shipping___en"
  }, {
    path: "/account/shopping-cart",
    component: _1c659eba,
    name: "account-shopping-cart___en"
  }, {
    path: "/account/user-information",
    component: _691afc48,
    name: "account-user-information___en"
  }, {
    path: "/account/wishlist",
    component: _10b491f7,
    name: "account-wishlist___en"
  }, {
    path: "/blog/blog-left-sidebar",
    component: _39099804,
    name: "blog-blog-left-sidebar___en"
  }, {
    path: "/blog/blog-list",
    component: _5cddb9e8,
    name: "blog-blog-list___en"
  }, {
    path: "/blog/blog-right-sidebar",
    component: _76e44bad,
    name: "blog-blog-right-sidebar___en"
  }, {
    path: "/blog/blog-small-thumbnail",
    component: _d453cab0,
    name: "blog-blog-small-thumbnail___en"
  }, {
    path: "/fr/blog",
    component: _6ae4d4f5,
    name: "blog___fr"
  }, {
    path: "/fr/search",
    component: _2d12b7ef,
    name: "search___fr"
  }, {
    path: "/fr/shop",
    component: _203e8d21,
    name: "shop___fr"
  }, {
    path: "/home/auto-part",
    component: _64ea6d97,
    name: "home-auto-part___en"
  }, {
    path: "/home/electronic",
    component: _ba7c82b4,
    name: "home-electronic___en"
  }, {
    path: "/home/furniture",
    component: _701eafb8,
    name: "home-furniture___en"
  }, {
    path: "/home/market-place",
    component: _20fc46e0,
    name: "home-market-place___en"
  }, {
    path: "/home/market-place-2",
    component: _6519fff6,
    name: "home-market-place-2___en"
  }, {
    path: "/home/market-place-3",
    component: _64fdd0f4,
    name: "home-market-place-3___en"
  }, {
    path: "/home/market-place-4",
    component: _64e1a1f2,
    name: "home-market-place-4___en"
  }, {
    path: "/home/organic",
    component: _149045b1,
    name: "home-organic___en"
  }, {
    path: "/home/technology",
    component: _926ead94,
    name: "home-technology___en"
  }, {
    path: "/page/about-us",
    component: _ceafa390,
    name: "page-about-us___en"
  }, {
    path: "/page/blank",
    component: _a19c592c,
    name: "page-blank___en"
  }, {
    path: "/page/contact-us",
    component: _122689c5,
    name: "page-contact-us___en"
  }, {
    path: "/page/faqs",
    component: _96e29a12,
    name: "page-faqs___en"
  }, {
    path: "/page/page-404",
    component: _8b889758,
    name: "page-page-404___en"
  }, {
    path: "/post/default",
    component: _07895fe6,
    name: "post-default___en"
  }, {
    path: "/post/detail-2",
    component: _23ef713e,
    name: "post-detail-2___en"
  }, {
    path: "/post/detail-3",
    component: _23d3423c,
    name: "post-detail-3___en"
  }, {
    path: "/post/detail-4",
    component: _23b7133a,
    name: "post-detail-4___en"
  }, {
    path: "/product/affiliate",
    component: _4bac5989,
    name: "product-affiliate___en"
  }, {
    path: "/product/boxed",
    component: _edcd5934,
    name: "product-boxed___en"
  }, {
    path: "/product/countdown",
    component: _71b9186d,
    name: "product-countdown___en"
  }, {
    path: "/product/extended",
    component: _150692a6,
    name: "product-extended___en"
  }, {
    path: "/product/full-content",
    component: _53acb4a2,
    name: "product-full-content___en"
  }, {
    path: "/product/groupped",
    component: _50e8ac24,
    name: "product-groupped___en"
  }, {
    path: "/product/on-sale",
    component: _4bb3e0b1,
    name: "product-on-sale___en"
  }, {
    path: "/product/out-of-stock",
    component: _78d3e09a,
    name: "product-out-of-stock___en"
  }, {
    path: "/product/sidebar",
    component: _2912f918,
    name: "product-sidebar___en"
  }, {
    path: "/shop/shop-carousel",
    component: _c6eb1db4,
    name: "shop-shop-carousel___en"
  }, {
    path: "/shop/shop-categories",
    component: _3a5e0462,
    name: "shop-shop-categories___en"
  }, {
    path: "/shop/shop-fullwidth",
    component: _14f9177e,
    name: "shop-shop-fullwidth___en"
  }, {
    path: "/shop/shop-sidebar",
    component: _5ccf4506,
    name: "shop-shop-sidebar___en"
  }, {
    path: "/shop/shop-sidebar-without-banner",
    component: _69590ca8,
    name: "shop-shop-sidebar-without-banner___en"
  }, {
    path: "/vendor/become-a-vendor",
    component: _2781c292,
    name: "vendor-become-a-vendor___en"
  }, {
    path: "/vendor/store-list",
    component: _a24e1e46,
    name: "vendor-store-list___en"
  }, {
    path: "/vendor/store-list-2",
    component: _56cd1ec2,
    name: "vendor-store-list-2___en"
  }, {
    path: "/vendor/vendor-store",
    component: _8486d9a2,
    name: "vendor-vendor-store___en"
  }, {
    path: "/fr/account/addresses",
    component: _1c9a7c60,
    name: "account-addresses___fr"
  }, {
    path: "/fr/account/checkout",
    component: _798280f8,
    name: "account-checkout___fr"
  }, {
    path: "/fr/account/compare",
    component: _b33314ba,
    name: "account-compare___fr"
  }, {
    path: "/fr/account/edit-address",
    component: _4f12ec63,
    name: "account-edit-address___fr"
  }, {
    path: "/fr/account/invoice-detail",
    component: _51512da3,
    name: "account-invoice-detail___fr"
  }, {
    path: "/fr/account/invoices",
    component: _2994f2d0,
    name: "account-invoices___fr"
  }, {
    path: "/fr/account/login",
    component: _229437a7,
    name: "account-login___fr"
  }, {
    path: "/fr/account/notifications",
    component: _18fe7fa6,
    name: "account-notifications___fr"
  }, {
    path: "/fr/account/order-tracking",
    component: _09e9a288,
    name: "account-order-tracking___fr"
  }, {
    path: "/fr/account/payment",
    component: _6329f244,
    name: "account-payment___fr"
  }, {
    path: "/fr/account/recent-viewed-product",
    component: _5aa99096,
    name: "account-recent-viewed-product___fr"
  }, {
    path: "/fr/account/register",
    component: _86ed2856,
    name: "account-register___fr"
  }, {
    path: "/fr/account/shipping",
    component: _0a939d60,
    name: "account-shipping___fr"
  }, {
    path: "/fr/account/shopping-cart",
    component: _1c659eba,
    name: "account-shopping-cart___fr"
  }, {
    path: "/fr/account/user-information",
    component: _691afc48,
    name: "account-user-information___fr"
  }, {
    path: "/fr/account/wishlist",
    component: _10b491f7,
    name: "account-wishlist___fr"
  }, {
    path: "/fr/blog/blog-left-sidebar",
    component: _39099804,
    name: "blog-blog-left-sidebar___fr"
  }, {
    path: "/fr/blog/blog-list",
    component: _5cddb9e8,
    name: "blog-blog-list___fr"
  }, {
    path: "/fr/blog/blog-right-sidebar",
    component: _76e44bad,
    name: "blog-blog-right-sidebar___fr"
  }, {
    path: "/fr/blog/blog-small-thumbnail",
    component: _d453cab0,
    name: "blog-blog-small-thumbnail___fr"
  }, {
    path: "/fr/home/auto-part",
    component: _64ea6d97,
    name: "home-auto-part___fr"
  }, {
    path: "/fr/home/electronic",
    component: _ba7c82b4,
    name: "home-electronic___fr"
  }, {
    path: "/fr/home/furniture",
    component: _701eafb8,
    name: "home-furniture___fr"
  }, {
    path: "/fr/home/market-place",
    component: _20fc46e0,
    name: "home-market-place___fr"
  }, {
    path: "/fr/home/market-place-2",
    component: _6519fff6,
    name: "home-market-place-2___fr"
  }, {
    path: "/fr/home/market-place-3",
    component: _64fdd0f4,
    name: "home-market-place-3___fr"
  }, {
    path: "/fr/home/market-place-4",
    component: _64e1a1f2,
    name: "home-market-place-4___fr"
  }, {
    path: "/fr/home/organic",
    component: _149045b1,
    name: "home-organic___fr"
  }, {
    path: "/fr/home/technology",
    component: _926ead94,
    name: "home-technology___fr"
  }, {
    path: "/fr/page/about-us",
    component: _ceafa390,
    name: "page-about-us___fr"
  }, {
    path: "/fr/page/blank",
    component: _a19c592c,
    name: "page-blank___fr"
  }, {
    path: "/fr/page/contact-us",
    component: _122689c5,
    name: "page-contact-us___fr"
  }, {
    path: "/fr/page/faqs",
    component: _96e29a12,
    name: "page-faqs___fr"
  }, {
    path: "/fr/page/page-404",
    component: _8b889758,
    name: "page-page-404___fr"
  }, {
    path: "/fr/post/default",
    component: _07895fe6,
    name: "post-default___fr"
  }, {
    path: "/fr/post/detail-2",
    component: _23ef713e,
    name: "post-detail-2___fr"
  }, {
    path: "/fr/post/detail-3",
    component: _23d3423c,
    name: "post-detail-3___fr"
  }, {
    path: "/fr/post/detail-4",
    component: _23b7133a,
    name: "post-detail-4___fr"
  }, {
    path: "/fr/product/affiliate",
    component: _4bac5989,
    name: "product-affiliate___fr"
  }, {
    path: "/fr/product/boxed",
    component: _edcd5934,
    name: "product-boxed___fr"
  }, {
    path: "/fr/product/countdown",
    component: _71b9186d,
    name: "product-countdown___fr"
  }, {
    path: "/fr/product/extended",
    component: _150692a6,
    name: "product-extended___fr"
  }, {
    path: "/fr/product/full-content",
    component: _53acb4a2,
    name: "product-full-content___fr"
  }, {
    path: "/fr/product/groupped",
    component: _50e8ac24,
    name: "product-groupped___fr"
  }, {
    path: "/fr/product/on-sale",
    component: _4bb3e0b1,
    name: "product-on-sale___fr"
  }, {
    path: "/fr/product/out-of-stock",
    component: _78d3e09a,
    name: "product-out-of-stock___fr"
  }, {
    path: "/fr/product/sidebar",
    component: _2912f918,
    name: "product-sidebar___fr"
  }, {
    path: "/fr/shop/shop-carousel",
    component: _c6eb1db4,
    name: "shop-shop-carousel___fr"
  }, {
    path: "/fr/shop/shop-categories",
    component: _3a5e0462,
    name: "shop-shop-categories___fr"
  }, {
    path: "/fr/shop/shop-fullwidth",
    component: _14f9177e,
    name: "shop-shop-fullwidth___fr"
  }, {
    path: "/fr/shop/shop-sidebar",
    component: _5ccf4506,
    name: "shop-shop-sidebar___fr"
  }, {
    path: "/fr/shop/shop-sidebar-without-banner",
    component: _69590ca8,
    name: "shop-shop-sidebar-without-banner___fr"
  }, {
    path: "/fr/vendor/become-a-vendor",
    component: _2781c292,
    name: "vendor-become-a-vendor___fr"
  }, {
    path: "/fr/vendor/store-list",
    component: _a24e1e46,
    name: "vendor-store-list___fr"
  }, {
    path: "/fr/vendor/store-list-2",
    component: _56cd1ec2,
    name: "vendor-store-list-2___fr"
  }, {
    path: "/fr/vendor/vendor-store",
    component: _8486d9a2,
    name: "vendor-vendor-store___fr"
  }, {
    path: "/fr/post/:id?",
    component: _acab3542,
    name: "post-id___fr"
  }, {
    path: "/fr/product/:id?",
    component: _2de39b14,
    name: "product-id___fr"
  }, {
    path: "/post/:id?",
    component: _acab3542,
    name: "post-id___en"
  }, {
    path: "/product/:id?",
    component: _2de39b14,
    name: "product-id___en"
  }, {
    path: "/",
    component: _01dc61d2,
    name: "index___en"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
