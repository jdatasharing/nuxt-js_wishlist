<template lang="html">
    <section class="ps-home-promotions">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="ps-collection mb-30" href="#">
                        <img
                            src="~/static/img/promotions/home-2-1.jpg"
                            alt="martfury"
                        />
                    </a>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="ps-collection mb-30" href="#">
                        <img
                            src="~/static/img/promotions/home-2-2.jpg"
                            alt="martfury"
                        />
                    </a>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: 'AutopartPromotions'
};
</script>

<style lang="scss" scoped></style>
