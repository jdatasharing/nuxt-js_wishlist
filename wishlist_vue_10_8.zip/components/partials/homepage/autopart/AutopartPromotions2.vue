<template lang="html">
    <section class="ps-promotion ps-promotion--2">
        <div class="container">
            <a class="ps-collection" href="#">
                <img
                    src="~/static/img/promotions/home-2-3.jpg"
                    alt="martfury"
                />
            </a>
        </div>
    </section>
</template>

<script>
export default {
    name: 'AutopartPromotions2'
};
</script>

<style lang="scss" scoped></style>
