<template lang="html">
    <div class="ps-promotions">
        <div class="container">
            <nuxt-link to="/shop" class="ps-collection">
                <img
                    src="~/static/img/promotions/home-4-1.jpg"
                    alt="martfury"
                />
            </nuxt-link>
        </div>
    </div>
</template>

<script>
export default {
    name: 'MarketPlace2Promotions'
};
</script>

<style lang="scss" scoped></style>
