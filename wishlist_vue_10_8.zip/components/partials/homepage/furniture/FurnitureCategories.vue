<template lang="html">
    <div class="ps-home-categories ps-section--furniture">
        <div class="container">
            <div class="ps-section__header">
                <h3>Shop by categories</h3>
            </div>
            <div class="ps-section__content">
                <div class="row">
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/1.png"
                                alt="martfury"
                            />
                            <p>Sofas</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/2.png"
                                alt="martfury"
                            />
                            <p>Chairs</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/3.png"
                                alt="martfury"
                            />
                            <p>Tables</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/4.png"
                                alt="martfury"
                            />
                            <p>TV Boards</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/5.png"
                                alt="martfury"
                            />
                            <p>Storages</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/6.png"
                                alt="martfury"
                            />
                            <p>Rugs</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/7.png"
                                alt="martfury"
                            />
                            <p>Lamp &amp; Lighting</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/8.png"
                                alt="martfury"
                            />
                            <p>Furnishings</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/9.png"
                                alt="martfury"
                            />
                            <p>Ottomans</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/10.png"
                                alt="martfury"
                            />
                            <p>Shelfs</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/11.png"
                                alt="martfury"
                            />
                            <p>Kid Furnitures</p>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-6 ">
                        <div class="ps-block--category">
                            <nuxt-link to="/shop">
                                <a></a>
                            </nuxt-link>
                            <img
                                src="~/static/img/categories/furniture/12.png"
                                alt="martfury"
                            />
                            <p>Kitchen</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'FurnitureCategories'
};
</script>

<style lang="scss" scoped></style>
