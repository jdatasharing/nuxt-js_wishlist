<template lang="html">
    <form class="ps-form--edit-address">
        <div class="ps-form__header">
            <h3>Billing address</h3>
        </div>
        <div class="ps-form__content">
            <div class="form-group">
                <label> FirstName <sup>*</sup> </label>
                <input type="text" placeholder="" class="form-control" />
            </div>
            <div class="form-group">
                <label> Lastname <sup>*</sup> </label>
                <input type="text" placeholder="" class="form-control" />
            </div>
            <div class="form-group">
                <label>
                    Company Name
                </label>
                <input type="text" placeholder="" class="form-control" />
            </div>
            <div class="form-group">
                <label> Country <sup>*</sup> </label>
                <input type="text" placeholder="" class="form-control" />
            </div>
            <div class="form-group">
                <label> Street Address <sup>*</sup> </label>
                <input type="text" placeholder="" class="form-control" />
            </div>
            <div class="form-group">
                <label> State <sup>*</sup> </label>
                <input type="text" placeholder="" class="form-control" />
            </div>
            <div class="form-group">
                <label> Postcode <sup>*</sup> </label>
                <input type="text" placeholder="" class="form-control" />
            </div>
            <div class="form-group">
                <label> Email address <sup>*</sup> </label>
                <input type="text" placeholder="" class="form-control" />
            </div>
            <div class="form-group submit">
                <button class="ps-btn">Save Address</button>
            </div>
        </div>
    </form>
</template>
