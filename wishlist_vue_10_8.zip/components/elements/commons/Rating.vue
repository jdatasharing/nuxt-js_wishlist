<template lang="html">
    <span class="ps-rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-o"></i>
    </span>
</template>

<script>
export default {
    name: 'Rating'
};
</script>

<style lang="scss" scoped></style>
