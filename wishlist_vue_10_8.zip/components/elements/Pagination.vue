<template lang="html">
    <div class="ps-pagination">
        <ul class="pagination">
            <li class="active">
                <a href="#">1</a>
            </li>
            <li>
                <a href="#">2</a>
            </li>
            <li>
                <a href="#">3</a>
            </li>
            <li>
                <a href="#">
                    Next Page
                    <i class="icon-chevron-right"></i>
                </a>
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    name: 'Pagination'
};
</script>

<style lang="scss" scoped></style>
