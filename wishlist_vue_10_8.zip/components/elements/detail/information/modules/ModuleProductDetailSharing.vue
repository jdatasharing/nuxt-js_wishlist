<template lang="html">
    <div class="ps-product__sharing">
        <a class="facebook" href="#">
            <i class="fa fa-facebook"></i>
        </a>
        <a class="twitter" href="#">
            <i class="fa fa-twitter"></i>
        </a>
        <a class="google" href="#">
            <i class="fa fa-google-plus"></i>
        </a>
        <a class="linkedin" href="#">
            <i class="fa fa-linkedin"></i>
        </a>
        <a class="instagram" href="#">
            <i class="fa fa-instagram"></i>
        </a>
    </div>
</template>

<script>
export default {
    name: 'ModuleProductDetailSharing'
};
</script>

<style lang="scss" scoped></style>
