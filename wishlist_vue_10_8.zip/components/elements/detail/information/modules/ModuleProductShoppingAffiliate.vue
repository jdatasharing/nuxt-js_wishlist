<template lang="html">
    <div class="ps-product__shopping">
        <a
            class="ps-btn"
            href="https://www.amazon.com/Premium-Military-Sunglasses-Polarized-protection/dp/B01GVRZ1BS/"
            target="_blank"
        >
            Purchase on Amazon
        </a>
        <div class="ps-product__actions">
            <a href="#">
                <i class="icon-heart"></i>
            </a>
            <a href="#">
                <i class="icon-chart-bars"></i>
            </a>
        </div>
    </div>
</template>

<script>
export default {
    name: 'ModuleProductShoppingAffiliate'
};
</script>

<style lang="scss" scoped></style>
