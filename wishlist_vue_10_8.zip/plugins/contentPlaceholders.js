import Vue from 'vue';
import VueContentPlaceholders from 'vue-content-placeholders';

Vue.use(VueContentPlaceholders);
