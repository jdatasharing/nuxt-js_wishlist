<template lang="html">
    <div class="ps-product__groupped">
        <div class="table-responsive">
            <table class="table ps-table--product-groupped">
                <tbody>
                    <tr>
                        <td>
                            <a class="ps-btn" href="#">
                                Read more
                            </a>
                        </td>
                        <td>
                            <a class="title" href="product-default.html">
                                Aroma Rice Cooker
                            </a>
                        </td>
                        <td>
                            <p>$275.50</p>
                            <p>
                                Status:
                                <span class="ps-tag--out-stock">
                                    Out of stock
                                </span>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="ps-btn" href="#">
                                Read more
                            </a>
                        </td>
                        <td>
                            <a class="title" href="product-default.html">
                                Korea Fabric Chair In Brown Color
                            </a>
                        </td>
                        <td>
                            <p>$320.54</p>
                            <p>
                                Status:
                                <span class="ps-tag--out-stock">
                                    Out of stock
                                </span>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="ps-btn" href="#">
                                Read more
                            </a>
                        </td>
                        <td>
                            <a class="title" href="product-default.html">
                                Set 14-Piece Knife From KichiKit
                            </a>
                        </td>
                        <td>
                            <p>$85.62</p>
                            <p>
                                Status:
                                <span class="ps-tag--out-stock">
                                    Out of stock
                                </span>
                            </p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
export default {
    name: 'ModuleProductGroupped'
};
</script>

<style lang="scss" scoped></style>
