<template lang="html">
    <div class="ps-home-promotions ps-home-promotions-2">
        <div class="container">
            <nuxt-link to="/shop">
                <a class="ps-collection">
                    <img
                        src="~/static/img/promotions/home-8/1.jpg"
                        alt="martfury"
                    />
                </a>
            </nuxt-link>
        </div>
    </div>
</template>

<script>
export default {
    name: 'FurniturePromotions2'
};
</script>

<style lang="scss" scoped></style>
