<template lang="html">
    <div class="ps-top-categories">
        <div class="container">
            <h3>Top categories of the month</h3>
            <div class="row">
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12 ">
                    <div class="ps-block--category">
                        <div class="ps-block__thumbnail">
                            <img
                                src="~/static/img/categories/organic/1.jpg"
                                alt="martfury"
                            />
                        </div>
                        <div class="ps-block__content">
                            <p>Milks &amp; Creams</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12 ">
                    <div class="ps-block--category">
                        <div class="ps-block__thumbnail">
                            <img
                                src="~/static/img/categories/organic/2.jpg"
                                alt="martfury"
                            />
                        </div>
                        <div class="ps-block__content">
                            <p>Fruits</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12 ">
                    <div class="ps-block--category">
                        <div class="ps-block__thumbnail">
                            <img
                                src="~/static/img/categories/organic/3.jpg"
                                alt="martfury"
                            />
                        </div>
                        <div class="ps-block__content">
                            <p>Vegetables</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12 ">
                    <div class="ps-block--category">
                        <div class="ps-block__thumbnail">
                            <img
                                src="~/static/img/categories/organic/4.jpg"
                                alt="martfury"
                            />
                        </div>
                        <div class="ps-block__content">
                            <p>Ocean Foods</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12 ">
                    <div class="ps-block--category">
                        <div class="ps-block__thumbnail">
                            <img
                                src="~/static/img/categories/organic/5.jpg"
                                alt="martfury"
                            />
                        </div>
                        <div class="ps-block__content">
                            <p>Butters &amp; Eggs</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12 ">
                    <div class="ps-block--category">
                        <div class="ps-block__thumbnail">
                            <img
                                src="~/static/img/categories/organic/6.jpg"
                                alt="martfury"
                            />
                        </div>
                        <div class="ps-block__content">
                            <p>Fresh Meats</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'OrganicTopCategories'
};
</script>

<style lang="scss" scoped></style>
