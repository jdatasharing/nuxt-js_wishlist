<template lang="html">
    <div class="ps-block--products-of-category">
        <div class="ps-block__categories">
            <h3>Consumer Electronics</h3>
            <ul>
                <li>
                    <nuxt-link to="/shop">
                        Best Seller
                    </nuxt-link>
                </li>
                <li>
                    <nuxt-link to="/shop">
                        New Arrivals
                    </nuxt-link>
                </li>
                <li>
                    <nuxt-link to="/shop">
                        TV Television
                    </nuxt-link>
                </li>
                <li>
                    <nuxt-link to="/shop">
                        Air Condition
                    </nuxt-link>
                </li>
                <li>
                    <nuxt-link to="/shop">
                        Washing Machine
                    </nuxt-link>
                </li>
                <li>
                    <nuxt-link to="/shop">
                        Microwave
                    </nuxt-link>
                </li>
                <li>
                    <nuxt-link to="/shop">
                        Refrigerator
                    </nuxt-link>
                </li>
                <li>
                    <nuxt-link to="/shop">
                        Office Electronic
                    </nuxt-link>
                </li>
                <li>
                    <nuxt-link to="/shop">
                        Car Electronic
                    </nuxt-link>
                </li>
                <li>
                    <nuxt-link to="/shop">
                        Sales & Deals
                    </nuxt-link>
                </li>
            </ul>
            <nuxt-link to="/shop" class="ps-block__more-link">
                View All
            </nuxt-link>
        </div>
        <div class="ps-block__slider">
            <div class="ps-carousel" v-swiper:mySwiper="carouselSingle">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <a href="#">
                            <img
                                src="~/static/img/slider/home-3/electronic-1.jpg"
                                alt="martfury"
                            />
                        </a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#">
                            <img
                                src="~/static/img/slider/home-3/electronic-2.jpg"
                                alt="martfury"
                            />
                        </a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#">
                            <img
                                src="~/static/img/slider/home-3/electronic-3.jpg"
                                alt="martfury"
                            />
                        </a>
                    </div>
                </div>
                <!--Carousel controls-->
                <div class="swiper-nav">
                    <span class="swiper-arrow swiper-prev"
                        ><i class="icon-chevron-left"></i
                    ></span>
                    <div class="swiper-arrow swiper-next">
                        <i class="icon-chevron-right"></i>
                    </div>
                </div>
                <div class="swiper-pagination swiper-pagination-bullets"></div>
            </div>
        </div>
        <div class="ps-block__product-box">
            <template v-for="(product, index) in products">
                <product-simple
                    v-if="index < 6"
                    :product="product"
                    :key="product.id"
                />
            </template>
        </div>
    </div>
</template>

<script>
import ProductDefault from '~/components/elements/product/ProductDefault';
import { mapState } from 'vuex';
import { carouselStandard, carouselSingle } from '~/utilities/carousel-helpers';
import { getColletionBySlug } from '~/utilities/product-helper';
import ProductSimple from '~/components/elements/product/ProductSimple';
export default {
    name: 'MarketConsumerElectronics',
    components: { ProductSimple, ProductDefault },
    props: {
        collectionSlug: {
            type: String,
            default: ''
        }
    },
    computed: {
        ...mapState({
            categories: state => state.collection.categories
        }),

        products() {
            return getColletionBySlug(this.categories, this.collectionSlug);
        }
    },
    data() {
        return {
            carouselSingle: {
                loop: true,
                slidesPerView: 1,
                spaceBetween: 1,
                navigation: {
                    nextEl: '.swiper-next',
                    prevEl: '.swiper-prev'
                }
            }
        };
    }
};
</script>
<style lang="scss" scoped></style>
