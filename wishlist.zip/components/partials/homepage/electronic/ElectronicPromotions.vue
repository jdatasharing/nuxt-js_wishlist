<template lang="html">
    <div class="ps-promotions">
        <div class="container">
            <nuxt-link to="/shop">
                <a class="ps-collection">
                    <img
                        src="~/static/img/promotions/home-7/3.jpg"
                        alt="martfury"
                    />
                </a>
            </nuxt-link>
        </div>
    </div>
</template>

<script>
export default {
    name: 'ElectronicPromotions'
};
</script>

<style lang="scss" scoped></style>
