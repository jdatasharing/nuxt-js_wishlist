<template lang="html">
    <div class="ps-home-categories">
        <div class="container">
            <div class="ps-section__header">
                <h3>Top Categories Of The Month</h3>
            </div>
            <div class="ps-section__content">
                <div class="row align-content-lg-stretch">
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12 ">
                        <div class="ps-block--category-2" data-mh="categories">
                            <div class="ps-block__thumbnail">
                                <img
                                    src="~/static/img/categories/shop/5.jpg"
                                    alt="martfury"
                                />
                            </div>
                            <div class="ps-block__content">
                                <h4>Electronics</h4>
                                <ul>
                                    <li>
                                        <nuxt-link to="/shop">
                                            TV Televisions
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Air Conditioners
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Washing Machines
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Audio & Theaters
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Audio & Theaters
                                        </nuxt-link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12 ">
                        <div class="ps-block--category-2" data-mh="categories">
                            <div class="ps-block__thumbnail">
                                <img
                                    src="~/static/img/categories/shop/1.jpg"
                                    alt="martfury"
                                />
                            </div>
                            <div class="ps-block__content">
                                <h4>Clothings</h4>
                                <ul>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Office Electronics
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Womens
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Mens
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Bags & Backpacks
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Accessories
                                        </nuxt-link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12 ">
                        <div class="ps-block--category-2" data-mh="categories">
                            <div class="ps-block__thumbnail">
                                <img
                                    src="~/static/img/categories/shop/9.jpg"
                                    alt="martfury"
                                />
                            </div>
                            <div class="ps-block__content">
                                <h4>Computers</h4>
                                <ul>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Desktop PC
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Laptop
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            PC Gaming
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Storage & Memory
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            PC Components
                                        </nuxt-link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12 ">
                        <div class="ps-block--category-2" data-mh="categories">
                            <div class="ps-block__thumbnail">
                                <img
                                    src="~/static/img/categories/shop/2.jpg"
                                    alt="martfury"
                                />
                            </div>
                            <div class="ps-block__content">
                                <h4>Home & Kitchen</h4>
                                <ul>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Funitures
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Decor
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Cookwares
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Utensil & Gadgets
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Garden Tools
                                        </nuxt-link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12 ">
                        <div class="ps-block--category-2" data-mh="categories">
                            <div class="ps-block__thumbnail">
                                <img
                                    src="~/static/img/categories/shop/10.jpg"
                                    alt="martfury"
                                />
                            </div>
                            <div class="ps-block__content">
                                <h4>Healthy & Beauty</h4>
                                <ul>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Makeup
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Skin Care
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Hair Care
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Tools & Equipments
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Perfurmes
                                        </nuxt-link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-12 ">
                        <div class="ps-block--category-2" data-mh="categories">
                            <div class="ps-block__thumbnail">
                                <img
                                    src="~/static/img/categories/shop/6.jpg"
                                    alt="martfury"
                                />
                            </div>
                            <div class="ps-block__content">
                                <h4>Jewelry & Watch</h4>
                                <ul>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Pendant
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Necklace
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Watch
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Bracelets
                                        </nuxt-link>
                                    </li>
                                    <li>
                                        <nuxt-link to="/shop">
                                            Accessories
                                        </nuxt-link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'MarketPlace2Categories'
};
</script>

<style lang="scss" scoped></style>
