<template lang="html">
    <div class="ps-best-sale-brands ps-section--furniture">
        <div class="container">
            <div class="ps-section__header">
                <h3>BEST SELLER BRANDS</h3>
            </div>
            <div class="ps-section__content">
                <ul class="ps-image-list">
                    <li>
                        <nuxt-link to="/shop">
                            <img
                                src="~/static/img/brand/2-1.jpg"
                                alt="martfury"
                            />
                        </nuxt-link>
                    </li>
                    <li>
                        <nuxt-link to="/shop">
                            <img
                                src="~/static/img/brand/2-2.jpg"
                                alt="martfury"
                            />
                        </nuxt-link>
                    </li>
                    <li>
                        <nuxt-link to="/shop">
                            <img
                                src="~/static/img/brand/2-3.jpg"
                                alt="martfury"
                            />
                        </nuxt-link>
                    </li>
                    <li>
                        <nuxt-link to="/shop">
                            <img
                                src="~/static/img/brand/2-4.jpg"
                                alt="martfury"
                            />
                        </nuxt-link>
                    </li>
                    <li>
                        <nuxt-link to="/shop">
                            <img
                                src="~/static/img/brand/2-5.jpg"
                                alt="martfury"
                            />
                        </nuxt-link>
                    </li>
                    <li>
                        <nuxt-link to="/shop">
                            <img
                                src="~/static/img/brand/2-6.jpg"
                                alt="martfury"
                            />
                        </nuxt-link>
                    </li>
                    <li>
                        <nuxt-link to="/shop">
                            <img
                                src="~/static/img/brand/2-7.jpg"
                                alt="martfury"
                            />
                        </nuxt-link>
                    </li>
                    <li>
                        <nuxt-link to="/shop">
                            <img
                                src="~/static/img/brand/2-8.jpg"
                                alt="martfury"
                            />
                        </nuxt-link>
                    </li>
                    <li>
                        <nuxt-link to="/shop">
                            <img
                                src="~/static/img/brand/2-9.jpg"
                                alt="martfury"
                            />
                        </nuxt-link>
                    </li>
                    <li>
                        <nuxt-link to="/shop">
                            <img
                                src="~/static/img/brand/2-10.jpg"
                                alt="martfury"
                            />
                        </nuxt-link>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'AutopartBestSaleBrand'
};
</script>

<style lang="scss" scoped></style>
