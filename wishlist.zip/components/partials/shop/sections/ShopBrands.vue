<template lang="html">
    <div class="ps-shop-brand">
        <nuxt-link to="/shop">
            <img src="~/static/img/brand/1.jpg" alt="martfury" />
        </nuxt-link>
        <nuxt-link to="/shop">
            <img src="~/static/img/brand/2.jpg" alt="martfury" />
        </nuxt-link>
        <nuxt-link to="/shop">
            <img src="~/static/img/brand/3.jpg" alt="martfury" />
        </nuxt-link>
        <nuxt-link to="/shop">
            <img src="~/static/img/brand/4.jpg" alt="martfury" />
        </nuxt-link>
        <nuxt-link to="/shop">
            <img src="~/static/img/brand/5.jpg" alt="martfury" />
        </nuxt-link>
        <nuxt-link to="/shop">
            <img src="~/static/img/brand/6.jpg" alt="martfury" />
        </nuxt-link>
        <nuxt-link to="/shop">
            <img src="~/static/img/brand/7.jpg" alt="martfury" />
        </nuxt-link>
        <nuxt-link to="/shop">
            <img src="~/static/img/brand/8.jpg" alt="martfury" />
        </nuxt-link>
    </div>
</template>

<script>
export default {
    name: 'ShopBrands'
};
</script>

<style lang="scss" scoped></style>
