<template lang="html">
    <ul class="ps-list--blog-links">
        <li class="active">
            <nuxt-link to="/blog">
                <a>All</a>
            </nuxt-link>
        </li>
        <li>
            <nuxt-link to="/blog">
                <a>Life Style</a>
            </nuxt-link>
        </li>
        <li>
            <nuxt-link to="/blog">
                <a>Technology</a>
            </nuxt-link>
        </li>
        <li>
            <nuxt-link to="/blog">
                <a>Entertaiment</a>
            </nuxt-link>
        </li>
        <li>
            <nuxt-link to="/blog">
                <a>Business</a>
            </nuxt-link>
        </li>
        <li>
            <nuxt-link to="/blog">
                <a>Others</a>
            </nuxt-link>
        </li>
        <li>
            <nuxt-link to="/blog">
                <a>Fashion</a>
            </nuxt-link>
        </li>
    </ul>
</template>

<script>
export default {
    name: 'BlogLinks'
};
</script>

<style lang="scss" scoped></style>
