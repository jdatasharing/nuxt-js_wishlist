let state = {
    posts: []
}

export default state