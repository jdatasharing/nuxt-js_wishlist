let getters = {
    posts: state => {
        return state.posts
    }
}

export default  getters